#!/usr/bin/env python3
"""Run respiratory aeration preprocessing + QTN/GAF/MTF metrics."""
from smallworld_qtn.preprocessing.respiratory_aeration import RespAerationConfig, run_dataset

if __name__ == "__main__":
    cfg = RespAerationConfig(out_dir="outputs/resp_aeration")
    run_dataset(cfg)
