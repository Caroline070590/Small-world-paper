#!/usr/bin/env python3
"""Run ECG preprocessing + QTN/GAF/MTF metrics for NSRDB and Fantasia."""
from smallworld_qtn.preprocessing.ecg_physionet import ECGConfig, run_dataset

if __name__ == "__main__":
    cfg = ECGConfig()
    run_dataset("nsrdb", "nsrdb", "outputs/ecg/nsrdb", cfg)
    run_dataset("fantasia", "fantasia", "outputs/ecg/fantasia", cfg)
