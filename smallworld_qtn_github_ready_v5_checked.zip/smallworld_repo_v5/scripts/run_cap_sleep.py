#!/usr/bin/env python3
"""Run CAP sleep controls preprocessing + QTN/GAF/MTF metrics."""
from smallworld_qtn.preprocessing.cap_sleep import CAPSleepConfig, run_all_modalities

if __name__ == "__main__":
    cfg = CAPSleepConfig(out_base_dir="outputs/sleep")
    run_all_modalities(cfg)
