#!/usr/bin/env python
"""Run EMG plantar preprocessing and QG/GAF/MTF metric extraction."""
from __future__ import annotations

import argparse
from smallworld_qtn.preprocessing.emg_plantar import EMGPlantarConfig, run_emg_plantar


def main() -> None:
    parser = argparse.ArgumentParser(description="PhysioNet plantar EMG -> QG/GAF/MTF small-world metrics")
    parser.add_argument("--mode", choices=["manifest", "run"], default="run")
    parser.add_argument("--fs", type=float, default=1000.0, help="Sampling frequency in Hz. Use 0 to skip filtering/epoch QC.")
    parser.add_argument("--out-dir", default="results/emg_plantar")
    parser.add_argument("--tmp-dir", default="tmp_emg_plantar")
    parser.add_argument("--n-jobs", type=int, default=2)
    parser.add_argument("--batch-size", type=int, default=4)
    parser.add_argument("--target-density", type=float, default=0.10)
    parser.add_argument("--n-randomizations", type=int, default=10)
    parser.add_argument("--use-flat-qc", action="store_true")
    parser.add_argument("--use-envelope", action="store_true")
    args = parser.parse_args()

    fs = None if args.fs <= 0 else args.fs
    config = EMGPlantarConfig(
        out_dir=args.out_dir,
        tmp_dir=args.tmp_dir,
        n_jobs=args.n_jobs,
        batch_size=args.batch_size,
        target_density=args.target_density,
        n_randomizations=args.n_randomizations,
        use_flat_qc=args.use_flat_qc,
        use_envelope=args.use_envelope,
    )
    run_emg_plantar(mode=args.mode, fs=fs, config=config)


if __name__ == "__main__":
    main()
