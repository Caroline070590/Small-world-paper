#!/usr/bin/env python3
"""Run FieldTrip Subject01 MEG preprocessing + QTN/GAF/MTF metrics."""
from smallworld_qtn.preprocessing.fieldtrip_meg import FieldTripMEGConfig, run_fieldtrip_meg

if __name__ == "__main__":
    cfg = FieldTripMEGConfig(out_dir="outputs/fieldtrip_meg")
    paths = run_fieldtrip_meg(cfg)
    print(paths)
