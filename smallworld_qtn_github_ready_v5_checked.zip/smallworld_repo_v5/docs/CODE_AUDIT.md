# Code audit and repository organization

## What was cleaned

The original working scripts were reorganized into a reusable Python package with:

- `src/smallworld_qtn/representations.py`
  - QG/QTN construction
  - GAF construction
  - MTF construction
  - `Q = round(2*T^(1/3))`

- `src/smallworld_qtn/network_metrics.py`
  - proportional thresholding
  - transitivity
  - characteristic path length on the giant connected component
  - random-network normalization
  - small-world index `sigma`
  - `gamma`, `lambda`, `zC`, `zL`, `omega`, `phi`
  - global efficiency

- `src/smallworld_qtn/pipeline.py`
  - common extraction function used by all datasets
  - computes QTN/GAF/MTF metrics from a cleaned `(T, n_channels)` matrix
  - averages metrics across channels/leads/signals

- `src/smallworld_qtn/preprocessing/`
  - `cap_sleep.py`: CAP sleep EEG/EMG/respiration preprocessing
  - `ecg_physionet.py`: PhysioNet ECG preprocessing for NSRDB and Fantasia
  - `emg_plantar.py`: plantar EMG preprocessing
  - `respiratory_aeration.py`: respiratory aeration preprocessing
  - `fieldtrip_meg.py`: FieldTrip CTF-MEG preprocessing
  - `common.py`: shared filtering, interpolation, epoch QC, and robust z-scoring helpers

- `scripts/`
  - small command-line entry points for each dataset
  - no plotting
  - no Jupyter notebooks

## Problems identified in the pasted working code

1. Several scripts were concatenated into one block, which creates invalid Python syntax, e.g. duplicated imports in the middle of files and accidental fragments such as ` import os`.
2. QTN/GAF/MTF functions and small-world metrics were duplicated in every dataset script, which increases the risk of inconsistent results.
3. ECG appeared in multiple competing versions, including one script with preprocessing and another older script without the same preprocessing.
4. CAP sleep preprocessing used FIR filters in one version and IIR filters in another. The repository version uses a configurable option and defaults to IIR for speed.
5. Some dataset-specific code mixed preprocessing, downloading, feature extraction, output writing, and plotting. The repository version separates these concerns and removes plotting.
6. Several scripts used notebook-style execution at the bottom. The repository now uses importable modules plus explicit scripts.
7. Long raw-file downloads are kept outside version control by `.gitignore`.

## Scientific reproducibility choices kept

- QTN lags are set to `(1, 2, 3)`.
- Density threshold is set to `0.10`.
- Default random seed is `1234`.
- Q is computed as `round(2*T^(1/3))`.
- GAF uses absolute values for thresholding, consistent with signed GAF matrices.
- QTN and MTF use non-absolute thresholding because their matrices are non-negative transition matrices.
- Metrics are averaged across channels/leads/regions after per-channel extraction.

## Syntax check

All Python files in `src/` and `scripts/` were checked with `ast.parse`.
