# Code organization report

The repository was reorganized to separate the scientific workflow into four layers:

1. **Dataset-specific preprocessing** in `src/smallworld_qtn/preprocessing/`.
2. **Time-series representations** in `src/smallworld_qtn/representations.py`.
3. **Small-world/network metrics** in `src/smallworld_qtn/network_metrics.py`.
4. **Reusable metric extraction pipeline** in `src/smallworld_qtn/pipeline.py`.

This removes duplicated QTN/GAF/MTF and graph-metric functions from individual dataset scripts and makes the GitHub repository easier to review, cite, and maintain.

## Included preprocessing modules

- `emg_plantar.py`: plantar EMG dataset.
- `ecg_physionet.py`: NSRDB and Fantasia ECG datasets.
- `cap_sleep.py`: CAP sleep EEG, EMG, respiration, and combined sleep modalities.
- `respiratory_aeration.py`: respiratory aeration dataset.
- `fieldtrip_meg.py`: FieldTrip Subject01 CTF-MEG dataset.

## Validation performed during packaging

- Removed `.ipynb` notebooks from the release ZIP.
- Removed plotting-only code from the new modular entry points.
- Added run scripts for each dataset.
- Checked Python syntax compilation for all `.py` files.

## Suggested final manual checks before submission

Because several scripts download remote public datasets, run each script once in a clean environment before the repository is made public. This will verify remote paths, dataset availability, and package versions.
