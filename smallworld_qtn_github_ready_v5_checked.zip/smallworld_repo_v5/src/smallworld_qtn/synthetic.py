"""Synthetic signal generators for QTN benchmarking."""
from __future__ import annotations
import numpy as np

def logistic_map(n: int = 500, r: float = 4.0, x0: float = 0.123, burn_in: int = 100) -> np.ndarray:
    x = np.empty(n + burn_in, dtype=float)
    x[0] = x0
    for i in range(1, n + burn_in):
        x[i] = r * x[i - 1] * (1 - x[i - 1])
    return x[burn_in:]

def ar1(n: int = 500, phi: float = 0.9, seed: int | None = None) -> np.ndarray:
    rng = np.random.default_rng(seed)
    e = rng.normal(size=n)
    x = np.zeros(n)
    for t in range(1, n):
        x[t] = phi * x[t - 1] + e[t]
    return x

def sinusoid(n: int = 500, frequency: float = 0.02, noise: float = 0.0, seed: int | None = None) -> np.ndarray:
    rng = np.random.default_rng(seed)
    t = np.arange(n)
    return np.sin(2 * np.pi * frequency * t) + noise * rng.normal(size=n)

def gaussian(n: int = 500, seed: int | None = None) -> np.ndarray:
    return np.random.default_rng(seed).normal(size=n)
