"""Small-world QTN/GAF/MTF analysis package."""

__version__ = "0.2.0"
