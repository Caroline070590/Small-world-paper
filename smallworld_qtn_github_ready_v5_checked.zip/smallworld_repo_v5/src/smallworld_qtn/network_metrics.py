"""Small-world and related graph metrics for QTN/GAF/MTF matrices.

This module contains only matrix-to-network conversion and graph metrics.
"""
from __future__ import annotations

from dataclasses import dataclass
import numpy as np
import networkx as nx


@dataclass(frozen=True)
class SmallWorldConfig:
    density: float = 0.10
    n_randomizations: int = 10
    rewires_per_edge: int = 5
    seed: int = 1234


def proportional_binary_from_weights(w: np.ndarray, density: float = 0.10, use_abs: bool = False) -> np.ndarray:
    """Threshold a weighted square matrix to a binary graph at proportional density."""
    w = np.asarray(w, dtype=float)
    if w.ndim != 2 or w.shape[0] != w.shape[1]:
        raise ValueError("Input matrix must be square.")
    n = w.shape[0]
    a = np.array(w, dtype=float, copy=True)
    a[~np.isfinite(a)] = 0.0
    np.fill_diagonal(a, 0.0)
    m = np.abs(a) if use_abs else a
    upper = np.triu(m, 1)
    vals = upper[upper > 0]
    out = np.zeros((n, n), dtype=int)
    if vals.size == 0 or n < 2:
        return out
    n_target = int(round(float(density) * n * (n - 1) / 2.0))
    n_target = max(1, min(n_target, vals.size))
    threshold = np.partition(vals, -n_target)[-n_target]
    out = (m >= threshold).astype(int)
    out = np.triu(out, 1)
    out = out + out.T
    np.fill_diagonal(out, 0)
    return out


def gcc_char_path_length_binary(b: np.ndarray) -> float:
    """Average shortest path length on the giant connected component."""
    g = nx.from_numpy_array(np.asarray(b, dtype=int))
    if g.number_of_edges() == 0:
        return np.nan
    comps = list(nx.connected_components(g))
    if not comps:
        return np.nan
    gcc = g.subgraph(max(comps, key=len)).copy()
    if gcc.number_of_nodes() < 2 or gcc.number_of_edges() == 0:
        return np.nan
    return float(nx.average_shortest_path_length(gcc))


def degree_preserving_randomize_binary(b: np.ndarray, swaps: int, seed: int) -> np.ndarray:
    """Degree-preserving binary graph randomization by double-edge swaps."""
    g = nx.from_numpy_array(np.asarray(b, dtype=int))
    if g.number_of_edges() == 0:
        return np.asarray(b, dtype=int).copy()
    swaps = max(1, int(swaps))
    try:
        nx.double_edge_swap(g, nswap=swaps, max_tries=max(10, 10 * swaps), seed=int(seed))
    except Exception:
        pass
    return nx.to_numpy_array(g, dtype=int)


def ring_lattice(n: int, m: int) -> np.ndarray:
    """Construct an approximate ring lattice with n nodes and about m edges."""
    if n < 3 or m <= 0:
        return np.zeros((n, n), dtype=int)
    r = max(1, int(round(m / n)))
    b = np.zeros((n, n), dtype=int)
    for i in range(n):
        for step in range(1, r + 1):
            j1 = (i + step) % n
            j2 = (i - step) % n
            b[i, j1] = b[j1, i] = 1
            b[i, j2] = b[j2, i] = 1
    np.fill_diagonal(b, 0)
    return b


def null_model_stats(b: np.ndarray, n_randomizations: int, rewires_per_edge: int, seed: int) -> tuple[float, float, float, float]:
    """Mean and SD of transitivity and path length for degree-preserving null graphs."""
    m = int(np.asarray(b).sum() // 2)
    swaps = max(1, int(rewires_per_edge) * max(1, m))
    rng = np.random.default_rng(seed)
    c_vals, l_vals = [], []
    for _ in range(int(n_randomizations)):
        br = degree_preserving_randomize_binary(b, swaps, int(rng.integers(0, 1_000_000_000)))
        c = nx.transitivity(nx.from_numpy_array(br))
        l = gcc_char_path_length_binary(br)
        if c > 0 and np.isfinite(l):
            c_vals.append(float(c))
            l_vals.append(float(l))

    def mean_sd(vals: list[float]) -> tuple[float, float]:
        if not vals:
            return np.nan, np.nan
        return float(np.mean(vals)), float(np.std(vals) if len(vals) > 1 else 0.0)

    c_mu, c_sd = mean_sd(c_vals)
    l_mu, l_sd = mean_sd(l_vals)
    return c_mu, c_sd, l_mu, l_sd


def small_world_omega_phi(b: np.ndarray, c: float, l: float, c_rand: float, l_rand: float) -> tuple[float, float]:
    """Compute omega and phi auxiliary small-world scores."""
    n = b.shape[0]
    m = int(np.asarray(b).sum() // 2)
    if n < 3 or m == 0 or not all(np.isfinite(v) for v in [c, l, c_rand, l_rand]):
        return np.nan, np.nan
    bl = ring_lattice(n, m)
    c_latt = nx.transitivity(nx.from_numpy_array(bl))
    l_latt = gcc_char_path_length_binary(bl)
    if c_latt == 0 or not np.isfinite(l_latt):
        return np.nan, np.nan
    omega = (l_rand / l) - (c / c_latt)
    denom_c = c_rand - c_latt
    denom_l = l_latt - l_rand
    if denom_c == 0 or denom_l == 0:
        return float(omega), np.nan
    dc = float(np.clip((c_rand - c) / denom_c, 0.0, 1.0))
    dl = float(np.clip((l - l_rand) / denom_l, 0.0, 1.0))
    phi = 1.0 - np.sqrt((dc**2 + dl**2) / 2.0)
    return float(omega), float(phi)


def compute_smallworld_metrics_from_w(
    w: np.ndarray,
    config: SmallWorldConfig | None = None,
    use_abs_for_threshold: bool = False,
) -> dict:
    """Compute small-world metrics from a weighted QTN/GAF/MTF matrix."""
    config = config or SmallWorldConfig()
    b = proportional_binary_from_weights(w, density=config.density, use_abs=use_abs_for_threshold)
    n = b.shape[0]
    g = nx.from_numpy_array(b)
    c_obs = float(nx.transitivity(g)) if n > 1 else np.nan
    l_obs = gcc_char_path_length_binary(b)
    c_mu, c_sd, l_mu, l_sd = null_model_stats(
        b,
        n_randomizations=config.n_randomizations,
        rewires_per_edge=config.rewires_per_edge,
        seed=config.seed,
    )
    gamma = c_obs / c_mu if c_mu and np.isfinite(c_mu) else np.nan
    lambd = l_obs / l_mu if l_mu and np.isfinite(l_mu) else np.nan
    sigma = gamma / lambd if lambd and np.isfinite(lambd) else np.nan
    zc = (c_obs - c_mu) / c_sd if c_sd and np.isfinite(c_sd) else np.nan
    zl = (l_obs - l_mu) / l_sd if l_sd and np.isfinite(l_sd) else np.nan
    omega, phi = small_world_omega_phi(b, c_obs, l_obs, c_mu, l_mu)
    return {
        "n_nodes": int(n),
        "density": float(b.sum() / (n * (n - 1))) if n > 1 else np.nan,
        "transitivity": c_obs,
        "char_path_len_gcc": float(l_obs) if np.isfinite(l_obs) else np.nan,
        "gamma_C_over_Crand": float(gamma) if np.isfinite(gamma) else np.nan,
        "lambda_L_over_Lrand": float(lambd) if np.isfinite(lambd) else np.nan,
        "sigma_small_world": float(sigma) if np.isfinite(sigma) else np.nan,
        "zC": float(zc) if np.isfinite(zc) else np.nan,
        "zL": float(zl) if np.isfinite(zl) else np.nan,
        "omega": float(omega) if np.isfinite(omega) else np.nan,
        "phi": float(phi) if np.isfinite(phi) else np.nan,
        "global_efficiency": float(nx.global_efficiency(g)),
        "n_edges": int(b.sum() // 2),
    }
