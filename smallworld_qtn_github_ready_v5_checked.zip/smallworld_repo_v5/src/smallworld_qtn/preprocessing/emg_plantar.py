"""PhysioNet plantar EMG preprocessing and QG/GAF/MTF metric extraction.

This module is intentionally script-friendly and notebook-free. It downloads the
plantar EMG TXT files from PhysioNet, applies conservative electrophysiological
preprocessing and quality control, then exports QG/GAF/MTF small-world measures.
"""
from __future__ import annotations

import io
import os
import re
import warnings
from dataclasses import dataclass
from pathlib import Path
from typing import Optional
from urllib.parse import urljoin

import networkx as nx
import numpy as np
import pandas as pd
import requests
from joblib import Parallel, delayed
from scipy import signal
from tqdm.auto import tqdm

warnings.filterwarnings("ignore", category=RuntimeWarning)


@dataclass
class EMGPlantarConfig:
    base_url: str = "https://physionet.org/files/plantar/1.0.0/"
    dataset_name: str = "emg_plantar"
    out_dir: str = "results/emg_plantar"
    tmp_dir: str = "tmp_emg_plantar"
    delete_raw_after_process: bool = True
    request_timeout: int = 120

    k_values: tuple[int, ...] = (1, 2, 3)
    target_density: float = 0.10
    n_randomizations: int = 10
    rewirings_per_edge: int = 5
    rng_seed: int = 1234

    max_samples: Optional[int] = None
    start_sample: int = 0
    n_jobs: int = 2
    batch_size: int = 4
    backend: str = "loky"

    do_detrend: bool = True
    emg_highpass_hz: float = 20.0
    emg_lowpass_hz: float = 450.0
    butter_order: int = 4
    do_notch: bool = True
    notch_hz: float = 50.0
    notch_q: float = 30.0
    use_envelope: bool = False
    envelope_lowpass_hz: float = 10.0

    min_valid_samples: int = 200
    min_finite_frac: float = 0.70
    min_std: float = 1e-12
    min_unique_values: int = 5
    max_abs_z: float = 10.0
    use_flat_qc: bool = False
    max_flat_frac: float = 0.98

    do_epoch_qc: bool = True
    epoch_sec: float = 2.0
    min_keep_epochs: int = 2
    ptp_threshold_mult: float = 12.0
    max_interp_gap_frac: float = 0.10


FILE_REGEX = re.compile(r"^[EP]_\d{3}_.+\.txt$", flags=re.IGNORECASE)
EXCLUDE_REGEXES = [
    re.compile(r"summary[-_ ]sheet", re.IGNORECASE),
    re.compile(r"readme", re.IGNORECASE),
    re.compile(r"license", re.IGNORECASE),
    re.compile(r"sha256sums", re.IGNORECASE),
    re.compile(r"\.pdf$", re.IGNORECASE),
]
NUM_RE = re.compile(r"[-+]?\d*\.?\d+(?:[eE][-+]?\d+)?")
METHODS = ("QTN", "GAF", "MTF")


def ensure_dir(path: str | Path) -> None:
    Path(path).mkdir(parents=True, exist_ok=True)


def compute_q_from_t(t: int) -> int:
    return max(3, int(round(2 * (int(t) ** (1 / 3)))))


def file_id_from_path(rel_path: str) -> str:
    return Path(rel_path).stem


def patient_id_from_path(rel_path: str) -> str:
    stem = Path(rel_path).stem
    match = re.match(r"^([EP]_\d{3})_", stem, flags=re.IGNORECASE)
    return match.group(1).upper() if match else stem


def output_paths(config: EMGPlantarConfig) -> dict[str, str]:
    od = config.out_dir
    ds = config.dataset_name
    return {
        "QTN_FILE": f"{od}/metrics_QTN_{ds}_per_file.csv",
        "GAF_FILE": f"{od}/metrics_GAF_{ds}_per_file.csv",
        "MTF_FILE": f"{od}/metrics_MTF_{ds}_per_file.csv",
        "QTN_SUBJ": f"{od}/metrics_QTN_{ds}_per_subject.csv",
        "GAF_SUBJ": f"{od}/metrics_GAF_{ds}_per_subject.csv",
        "MTF_SUBJ": f"{od}/metrics_MTF_{ds}_per_subject.csv",
        "SKIP": f"{od}/skipped_{ds}.csv",
        "MANIFEST": f"{od}/manifest_{ds}.csv",
    }


def discover_files(config: EMGPlantarConfig) -> list[str]:
    url = urljoin(config.base_url, "SHA256SUMS.txt")
    response = requests.get(url, timeout=config.request_timeout)
    response.raise_for_status()

    files: list[str] = []
    for line in response.text.splitlines():
        parts = line.strip().split()
        if len(parts) < 2:
            continue
        rel_path = parts[-1].lstrip("./")
        if rel_path.lower().endswith("sha256sums.txt"):
            continue
        if not FILE_REGEX.match(rel_path):
            continue
        if any(rx.search(rel_path) for rx in EXCLUDE_REGEXES):
            continue
        files.append(rel_path)

    files = sorted(set(files))
    if not files:
        raise RuntimeError("No plantar EMG TXT files matched the discovery pattern.")
    return files


def download_file(url: str, local_path: str, timeout: int) -> None:
    if os.path.exists(local_path) and os.path.getsize(local_path) > 0:
        return
    ensure_dir(Path(local_path).parent)
    tmp = local_path + ".part"
    with requests.get(url, stream=True, timeout=timeout) as response:
        response.raise_for_status()
        with open(tmp, "wb") as handle:
            for chunk in response.iter_content(chunk_size=1024 * 1024):
                if chunk:
                    handle.write(chunk)
    os.replace(tmp, local_path)


def read_numeric_matrix_any(filepath: str) -> np.ndarray:
    raw = Path(filepath).read_bytes()
    text = raw.decode("utf-8", errors="ignore")
    text = re.sub(r"(\d),(\d)", r"\1.\2", text)

    for delimiter in (None, " ", "\t", ",", ";"):
        try:
            arr = np.genfromtxt(io.StringIO(text), delimiter=delimiter, invalid_raise=False)
            arr = np.asarray(arr, dtype=float)
            if arr.ndim == 1:
                arr = arr.reshape(-1, 1) if arr.size else arr.reshape(0, 0)
            if arr.size:
                arr = arr[np.any(np.isfinite(arr), axis=1)]
                arr = arr[:, np.any(np.isfinite(arr), axis=0)]
            if arr.size:
                return arr
        except Exception:
            continue

    rows = []
    for line in text.splitlines():
        nums = NUM_RE.findall(line)
        if nums:
            rows.append([float(x) for x in nums])
    if not rows:
        return np.zeros((0, 0), dtype=float)

    width = max(len(row) for row in rows)
    out = np.full((len(rows), width), np.nan, dtype=float)
    for i, row in enumerate(rows):
        out[i, : len(row)] = row
    out = out[np.any(np.isfinite(out), axis=1)]
    out = out[:, np.any(np.isfinite(out), axis=0)]
    return out


def ensure_time_by_channels(x: np.ndarray, min_valid_samples: int) -> np.ndarray:
    x = np.asarray(x, dtype=float)
    if x.ndim != 2:
        x = np.atleast_2d(x)
    rows, cols = x.shape
    if rows == 1 and cols > 1:
        return x.T
    if (rows < min_valid_samples and cols >= min_valid_samples) or (rows < cols and cols >= 50):
        return x.T
    return x


def interpolate_short_gaps(x: np.ndarray, max_gap_frac: float) -> np.ndarray:
    x = np.asarray(x, dtype=float).copy()
    finite = np.isfinite(x)
    if x.size == 0 or finite.sum() == 0:
        return x
    if finite.all():
        return x

    idx = np.arange(x.size)
    missing = ~finite
    x[missing] = np.interp(idx[missing], idx[finite], x[finite])

    starts = np.where(np.diff(np.r_[False, missing, False].astype(int)) == 1)[0]
    ends = np.where(np.diff(np.r_[False, missing, False].astype(int)) == -1)[0]
    max_gap = max((e - s) for s, e in zip(starts, ends)) if len(starts) else 0
    if max_gap > max_gap_frac * x.size:
        raise ValueError(f"Gap too long: {max_gap} samples.")
    return x


def robust_zscore(x: np.ndarray, max_abs_z: float) -> np.ndarray:
    med = np.nanmedian(x)
    mad = np.nanmedian(np.abs(x - med))
    scale = 1.4826 * mad
    if not np.isfinite(scale) or scale == 0:
        std = np.nanstd(x)
        scale = std if np.isfinite(std) and std > 0 else 1.0
    return np.clip((x - med) / scale, -max_abs_z, max_abs_z)


def flat_fraction_scale_aware(x: np.ndarray) -> float:
    if x.size < 2:
        return 1.0
    dx = np.diff(x)
    eps = max(1e-12, 1e-6 * float(np.nanstd(x)))
    return float(np.mean(np.abs(dx) <= eps))


def butter_sos(fs: float, btype: str, cutoff, order: int):
    nyq = 0.5 * fs
    if btype in ("highpass", "lowpass"):
        w = float(cutoff) / nyq
        if not (0 < w < 1):
            return None
        return signal.butter(order, w, btype=btype, output="sos")
    if btype == "bandpass":
        lo, hi = cutoff
        hi = min(float(hi), nyq * 0.99)
        lo = float(lo)
        if not (0 < lo < hi < nyq):
            return None
        return signal.butter(order, [lo / nyq, hi / nyq], btype="bandpass", output="sos")
    return None


def notch_filter_1d(x: np.ndarray, fs: float, f0: float, quality: float) -> np.ndarray:
    if f0 <= 0 or f0 >= 0.5 * fs:
        return x
    b, a = signal.iirnotch(w0=f0, Q=quality, fs=fs)
    return signal.filtfilt(b, a, x)


def epoch_qc_keep_mask(x: np.ndarray, fs: Optional[float], config: EMGPlantarConfig) -> np.ndarray:
    if not config.do_epoch_qc or fs is None or not np.isfinite(fs) or fs <= 0:
        return np.ones(1, dtype=bool)
    epoch_len = max(1, int(round(config.epoch_sec * fs)))
    n_epochs = len(x) // epoch_len
    if n_epochs == 0:
        return np.zeros(0, dtype=bool)
    epochs = x[: n_epochs * epoch_len].reshape(n_epochs, epoch_len)
    ptp = np.ptp(epochs, axis=1)
    med = np.median(ptp)
    mad = np.median(np.abs(ptp - med))
    scale = 1.4826 * mad if mad > 0 else (np.std(ptp) if np.std(ptp) > 0 else 1.0)
    threshold = med + config.ptp_threshold_mult * scale
    return ptp <= threshold


def preprocess_emg_signal(x: np.ndarray, fs: Optional[float], config: EMGPlantarConfig) -> tuple[np.ndarray, dict]:
    qc: dict[str, float | int] = {}
    x = np.asarray(x, dtype=float)
    if x.size < config.min_valid_samples:
        raise ValueError(f"Too few samples: n={x.size}.")

    finite = np.isfinite(x)
    qc["finite_frac_before"] = float(finite.mean())
    qc["n_total"] = int(x.size)
    qc["n_finite_before"] = int(finite.sum())
    if qc["finite_frac_before"] < config.min_finite_frac:
        raise ValueError(f"Too many NaNs: finite_frac={qc['finite_frac_before']:.3f}")

    x = interpolate_short_gaps(x, config.max_interp_gap_frac)
    if config.do_detrend:
        x = signal.detrend(x, type="constant")

    if fs is not None and np.isfinite(fs) and fs > 0:
        fs = float(fs)
        hp = butter_sos(fs, "highpass", config.emg_highpass_hz, config.butter_order)
        if hp is not None:
            x = signal.sosfiltfilt(hp, x)
        if config.do_notch:
            x = notch_filter_1d(x, fs, config.notch_hz, config.notch_q)
        lp = butter_sos(fs, "lowpass", min(config.emg_lowpass_hz, 0.5 * fs * 0.99), config.butter_order)
        if lp is not None:
            x = signal.sosfiltfilt(lp, x)
        if config.use_envelope:
            x = np.abs(x)
            env_lp = butter_sos(fs, "lowpass", min(config.envelope_lowpass_hz, 0.5 * fs * 0.99), config.butter_order)
            if env_lp is not None:
                x = signal.sosfiltfilt(env_lp, x)

    if not np.all(np.isfinite(x)):
        raise ValueError("Non-finite values after interpolation/filtering.")

    qc["std_before_z"] = float(np.std(x))
    qc["n_unique_before_z"] = int(np.unique(np.round(x, 10)).size)
    qc["flat_frac_before_z"] = flat_fraction_scale_aware(x)
    if qc["std_before_z"] <= config.min_std:
        raise ValueError("Variance too small.")
    if qc["n_unique_before_z"] < config.min_unique_values:
        raise ValueError("Too few unique values.")
    if config.use_flat_qc and qc["flat_frac_before_z"] > config.max_flat_frac:
        raise ValueError("Too much flat signal.")

    keep = epoch_qc_keep_mask(x, fs, config)
    if keep.size > 0 and fs is not None and np.isfinite(fs) and fs > 0:
        epoch_len = max(1, int(round(config.epoch_sec * fs)))
        n_epochs = len(x) // epoch_len
        x = x[: n_epochs * epoch_len].reshape(n_epochs, epoch_len)[keep].reshape(-1)
        qc["n_epochs_total"] = int(n_epochs)
        qc["n_epochs_kept"] = int(keep.sum())
        qc["epochs_kept_frac"] = float(keep.mean()) if keep.size else np.nan
        if keep.sum() < config.min_keep_epochs:
            raise ValueError(f"Too few clean epochs kept: {keep.sum()}.")
    else:
        qc["n_epochs_total"] = np.nan
        qc["n_epochs_kept"] = np.nan
        qc["epochs_kept_frac"] = np.nan

    x = robust_zscore(x, config.max_abs_z)
    qc["n_final"] = int(x.size)
    qc["std_final"] = float(np.std(x))
    if x.size < config.min_valid_samples:
        raise ValueError("Too few samples after preprocessing.")
    return x, qc


def load_emg_matrix(filepath: str, fs: Optional[float], config: EMGPlantarConfig) -> tuple[np.ndarray, list[str], pd.DataFrame]:
    x0 = read_numeric_matrix_any(filepath)
    if x0.size == 0:
        raise ValueError("No numeric data after parsing.")
    x = ensure_time_by_channels(x0, config.min_valid_samples)
    x = x[np.any(np.isfinite(x), axis=1)]
    x = x[:, np.any(np.isfinite(x), axis=0)]
    if x.size == 0:
        raise ValueError("No numeric data after orientation/cleaning.")

    kept, names, qc_rows = [], [], []
    for j in range(x.shape[1]):
        clean, qc = preprocess_emg_signal(x[:, j], fs, config)
        kept.append(clean)
        names.append(f"ch{j}")
        qc["signal_name"] = f"ch{j}"
        qc_rows.append(qc)

    min_len = min(len(v) for v in kept)
    return np.column_stack([v[:min_len] for v in kept]), names, pd.DataFrame(qc_rows)


def downsample_to_length(x: np.ndarray, length: int) -> np.ndarray:
    x = np.asarray(x, dtype=float)
    if x.size == length:
        return x.copy()
    if x.size < 2:
        return np.full(length, float(x[0]) if x.size else 0.0)
    xp = np.linspace(0.0, 1.0, x.size)
    return np.interp(np.linspace(0.0, 1.0, length), xp, x)


def quantile_graph(x: np.ndarray, q: int, lags: tuple[int, ...]) -> np.ndarray:
    mat = np.zeros((q, q), dtype=float)
    n = x.size
    ranks = np.argsort(np.argsort(x))
    edges = np.linspace(0, n, q + 1, dtype=int)
    states = np.clip(np.searchsorted(edges, ranks, side="right") - 1, 0, q - 1)
    for lag in lags:
        if 0 < lag < n:
            np.add.at(mat, (states[:-lag], states[lag:]), 1.0)
    return mat


def gramian_angular_field(x: np.ndarray) -> np.ndarray:
    lo, hi = float(np.min(x)), float(np.max(x))
    rng = hi - lo if hi != lo else 1.0
    scaled = np.clip(2 * (x - lo) / rng - 1, -1, 1)
    phi = np.arccos(scaled)
    return np.cos(phi[:, None] + phi[None, :])


def markov_transition_field(x: np.ndarray, q: int) -> np.ndarray:
    lo, hi = float(np.min(x)), float(np.max(x))
    rng = hi - lo if hi != lo else 1.0
    z = (x - lo) / rng
    bins = np.linspace(0, 1, q + 1)
    states = np.clip(np.digitize(z, bins) - 1, 0, q - 1)
    trans = np.zeros((q, q), dtype=float)
    np.add.at(trans, (states[:-1], states[1:]), 1.0)
    row_sums = trans.sum(axis=1, keepdims=True)
    trans = np.divide(trans, row_sums, out=np.zeros_like(trans), where=row_sums != 0)
    return trans[states[:, None], states[None, :]]


def proportional_binary_from_weights(w: np.ndarray, density: float, use_abs: bool) -> np.ndarray:
    w = np.asarray(w, dtype=float).copy()
    n = w.shape[0]
    np.fill_diagonal(w, 0.0)
    m = np.abs(w) if use_abs else w
    vals = np.triu(m, 1)
    vals = vals[vals > 0]
    out = np.zeros((n, n), dtype=int)
    if vals.size == 0:
        return out
    n_keep = max(1, min(int(round(density * n * (n - 1) / 2)), vals.size))
    threshold = np.partition(vals, -n_keep)[-n_keep]
    out = (m >= threshold).astype(int)
    out = np.triu(out, 1)
    out = out + out.T
    np.fill_diagonal(out, 0)
    return out


def char_path_len_gcc(binary: np.ndarray) -> float:
    graph = nx.from_numpy_array(binary)
    if graph.number_of_edges() == 0:
        return np.nan
    comp = max(nx.connected_components(graph), key=len)
    gcc = graph.subgraph(comp).copy()
    if gcc.number_of_nodes() < 2 or gcc.number_of_edges() == 0:
        return np.nan
    return float(nx.average_shortest_path_length(gcc))


def random_null_stats(binary: np.ndarray, config: EMGPlantarConfig, seed: int) -> tuple[float, float, float, float]:
    graph0 = nx.from_numpy_array(binary)
    m = graph0.number_of_edges()
    swaps = max(1, config.rewirings_per_edge * m)
    rng = np.random.default_rng(seed)
    c_vals, l_vals = [], []
    for _ in range(config.n_randomizations):
        graph = graph0.copy()
        try:
            nx.double_edge_swap(graph, nswap=swaps, max_tries=max(10 * swaps, 100), seed=int(rng.integers(1_000_000)))
        except Exception:
            pass
        br = nx.to_numpy_array(graph, dtype=int)
        c_vals.append(nx.transitivity(graph))
        l_vals.append(char_path_len_gcc(br))
    return float(np.nanmean(c_vals)), float(np.nanstd(c_vals)), float(np.nanmean(l_vals)), float(np.nanstd(l_vals))


def compute_smallworld_metrics(w: np.ndarray, config: EMGPlantarConfig, seed: int, use_abs: bool) -> dict:
    binary = proportional_binary_from_weights(w, config.target_density, use_abs=use_abs)
    graph = nx.from_numpy_array(binary)
    c_obs = float(nx.transitivity(graph)) if graph.number_of_nodes() else np.nan
    l_obs = char_path_len_gcc(binary)
    c_rand, c_sd, l_rand, l_sd = random_null_stats(binary, config, seed)
    gamma = c_obs / c_rand if c_rand and np.isfinite(c_rand) else np.nan
    lambd = l_obs / l_rand if l_rand and np.isfinite(l_rand) else np.nan
    sigma = gamma / lambd if lambd and np.isfinite(lambd) else np.nan
    return {
        "n_nodes": int(binary.shape[0]),
        "density": float(binary.sum() / (binary.shape[0] * (binary.shape[0] - 1))) if binary.shape[0] > 1 else np.nan,
        "transitivity": c_obs,
        "char_path_len_gcc": l_obs,
        "gamma_C_over_Crand": gamma,
        "lambda_L_over_Lrand": lambd,
        "sigma_small_world": sigma,
        "zC": (c_obs - c_rand) / c_sd if c_sd and np.isfinite(c_sd) else np.nan,
        "zL": (l_obs - l_rand) / l_sd if l_sd and np.isfinite(l_sd) else np.nan,
        "global_efficiency": float(nx.global_efficiency(graph)) if graph.number_of_nodes() else np.nan,
    }


def slice_signals(signals: np.ndarray, config: EMGPlantarConfig) -> np.ndarray:
    start = int(config.start_sample or 0)
    if config.max_samples is None:
        return signals[start:, :]
    return signals[start : start + int(config.max_samples), :]


def file_to_method_rows(local_path: str, fs: Optional[float], config: EMGPlantarConfig, seed_base: int) -> dict[str, dict]:
    signals, channel_names, qc_df = load_emg_matrix(local_path, fs, config)
    signals = slice_signals(signals, config)
    t = signals.shape[0]
    if t < 50:
        raise ValueError("Too few samples after preprocessing.")
    q = compute_q_from_t(t)

    per_method = {method: [] for method in METHODS}
    qc_summary = qc_df.mean(numeric_only=True).to_dict()

    for channel_idx in range(signals.shape[1]):
        x = signals[:, channel_idx].astype(float)
        x = x[np.isfinite(x)]
        if x.size < 50:
            continue

        qg = quantile_graph(x, q, config.k_values)
        qg = qg + qg.T
        per_method["QTN"].append(compute_smallworld_metrics(qg, config, seed_base + 100 * channel_idx + 1, use_abs=False))

        xq = downsample_to_length(x, q)
        gaf = gramian_angular_field(xq)
        per_method["GAF"].append(compute_smallworld_metrics(gaf, config, seed_base + 100 * channel_idx + 2, use_abs=True))

        mtf = markov_transition_field(xq, q)
        per_method["MTF"].append(compute_smallworld_metrics(mtf, config, seed_base + 100 * channel_idx + 3, use_abs=False))

    rows = {}
    for method, values in per_method.items():
        if not values:
            raise ValueError(f"No valid signals produced metrics for {method}.")
        avg = pd.DataFrame(values).mean(numeric_only=True).to_dict()
        avg.update(
            {
                "fs_hz": float(fs) if fs is not None else np.nan,
                "n_signals": int(signals.shape[1]),
                "T_used_samples": int(t),
                "Q_used": int(q),
                "signal_cols": ";".join(channel_names),
                "use_envelope": bool(config.use_envelope),
                "use_flat_qc": bool(config.use_flat_qc),
                "qc_finite_frac_before_mean": qc_summary.get("finite_frac_before", np.nan),
                "qc_std_before_z_mean": qc_summary.get("std_before_z", np.nan),
                "qc_flat_frac_before_z_mean": qc_summary.get("flat_frac_before_z", np.nan),
                "qc_epochs_kept_frac_mean": qc_summary.get("epochs_kept_frac", np.nan),
                "qc_std_final_mean": qc_summary.get("std_final", np.nan),
            }
        )
        rows[method] = avg
    return rows


def load_done_ids(csv_path: str, id_col: str) -> set[str]:
    if not os.path.exists(csv_path):
        return set()
    try:
        df = pd.read_csv(csv_path)
        return set(df[id_col].astype(str).tolist()) if id_col in df else set()
    except Exception:
        return set()


def append_rows(csv_path: str, rows: list[dict]) -> None:
    if not rows:
        return
    pd.DataFrame(rows).to_csv(csv_path, mode="a", header=not os.path.exists(csv_path), index=False)


def compute_one_file(rel_path: str, fs: Optional[float], task_i: int, config: EMGPlantarConfig):
    url = urljoin(config.base_url, rel_path)
    local_path = os.path.join(config.tmp_dir, rel_path)
    file_id = file_id_from_path(rel_path)
    patient_id = patient_id_from_path(rel_path)

    try:
        download_file(url, local_path, config.request_timeout)
        rows = file_to_method_rows(local_path, fs, config, seed_base=config.rng_seed + 100000 * task_i)
        for method in METHODS:
            rows[method].update(
                {
                    "file_id": file_id,
                    "patient_id": patient_id,
                    "dataset": config.dataset_name,
                    "source_file": rel_path,
                }
            )
        return file_id, rows, None
    except Exception as exc:
        return file_id, None, {
            "dataset": config.dataset_name,
            "method": "ALL",
            "record_or_patient": rel_path,
            "file_id": file_id,
            "patient_id": patient_id,
            "reason": str(exc),
        }
    finally:
        if config.delete_raw_after_process:
            try:
                os.remove(local_path)
            except OSError:
                pass


def aggregate_per_subject(file_csv: str, out_csv: str) -> None:
    if not os.path.exists(file_csv):
        return
    df = pd.read_csv(file_csv)
    if df.empty or "patient_id" not in df:
        return
    numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    grouped = df.groupby("patient_id")[numeric_cols].mean().reset_index()
    if "dataset" in df:
        grouped.insert(1, "dataset", df.groupby("patient_id")["dataset"].first().values)
    grouped["n_files_used"] = df.groupby("patient_id")["file_id"].nunique().values if "file_id" in df else df.groupby("patient_id").size().values
    grouped["aggregation"] = "mean_over_files"
    grouped.to_csv(out_csv, index=False)


def run_emg_plantar(mode: str = "manifest", fs: Optional[float] = None, config: Optional[EMGPlantarConfig] = None) -> dict[str, str]:
    if mode not in {"manifest", "run"}:
        raise ValueError("mode must be 'manifest' or 'run'.")
    config = config or EMGPlantarConfig()
    ensure_dir(config.out_dir)
    ensure_dir(config.tmp_dir)
    paths = output_paths(config)

    files = discover_files(config)
    pd.DataFrame(
        [{"source_file": p, "file_id": file_id_from_path(p), "patient_id": patient_id_from_path(p)} for p in files]
    ).to_csv(paths["MANIFEST"], index=False)
    print(f"[{config.dataset_name}] wrote manifest: {paths['MANIFEST']} (n={len(files)})")

    if mode == "manifest":
        return paths

    done = (
        load_done_ids(paths["QTN_FILE"], "file_id")
        & load_done_ids(paths["GAF_FILE"], "file_id")
        & load_done_ids(paths["MTF_FILE"], "file_id")
    )
    tasks = [(rel, i + 1) for i, rel in enumerate(files) if file_id_from_path(rel) not in done]
    print(f"[{config.dataset_name}] fs={fs} | discovered={len(files)} | pending={len(tasks)} | n_jobs={config.n_jobs}")

    for start in tqdm(range(0, len(tasks), config.batch_size), desc=f"{config.dataset_name} batches", unit="batch"):
        chunk = tasks[start : start + config.batch_size]
        results = Parallel(n_jobs=config.n_jobs, backend=config.backend)(
            delayed(compute_one_file)(rel, fs, task_i, config) for rel, task_i in chunk
        )
        rows = {method: [] for method in METHODS}
        skips = []
        for _, method_rows, skip in results:
            if method_rows is not None:
                for method in METHODS:
                    rows[method].append(method_rows[method])
            if skip is not None:
                skips.append(skip)
        append_rows(paths["QTN_FILE"], rows["QTN"])
        append_rows(paths["GAF_FILE"], rows["GAF"])
        append_rows(paths["MTF_FILE"], rows["MTF"])
        append_rows(paths["SKIP"], skips)

    aggregate_per_subject(paths["QTN_FILE"], paths["QTN_SUBJ"])
    aggregate_per_subject(paths["GAF_FILE"], paths["GAF_SUBJ"])
    aggregate_per_subject(paths["MTF_FILE"], paths["MTF_SUBJ"])
    print(f"[{config.dataset_name}] done. Outputs in {config.out_dir}")
    return paths
