"""CAP Sleep healthy-control preprocessing and QTN/GAF/MTF metric extraction.

Processes CAP database controls n1-n16 and can extract EEG, EMG, RESP, and
ALL_SLEEP modalities over NREM or whole-night samples. No plotting code is included.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Tuple
from urllib.parse import urljoin
import os
import re
import shutil
import time
import warnings

import requests
import numpy as np
import pandas as pd
import mne
from joblib import Parallel, delayed
from tqdm import tqdm

from smallworld_qtn.network_metrics import SmallWorldConfig
from smallworld_qtn.pipeline import extract_metrics_from_matrix
from .common import robust_zscore

warnings.filterwarnings("ignore", category=RuntimeWarning)

BASE_URL = "https://physionet.org/files/capslpdb/1.0.0/"
NREM_EVENTS = {"SLEEP-S1", "SLEEP-S2", "SLEEP-S3", "SLEEP-S4"}
CHANNEL_REGEX = {
    "EEG": r"EEG|Fpz|Pz|C3|C4|F3|F4|O1|O2",
    "EMG": r"EMG|Chin|Submental|Submentalis|Tibial",
    "RESP": r"Resp|Airflow|Nasal|Thor|Abdo|Abdominal|Thoracic|SaO2|SpO2|Flow",
    "ALL_SLEEP": r"EEG|EOG|EMG|Chin|Submental|Submentalis|Tibial|Resp|Airflow|Nasal|Thor|Abdo|Abdominal|Thoracic|SaO2|SpO2|Flow",
}
PREPROC = {
    "EEG": {"l_freq": 0.5, "h_freq": 40.0, "notch": True},
    "EMG": {"l_freq": 10.0, "h_freq": 45.0, "notch": True},
    "RESP": {"l_freq": 0.01, "h_freq": 1.0, "notch": False},
    "ALL_SLEEP": {"l_freq": None, "h_freq": None, "notch": False},
}


@dataclass
class CAPSleepConfig:
    dataset_name: str = "cap_sleep_controls"
    out_base_dir: str = "sleep_outputs"
    tmp_dir: str = "tmp_cap_sleep"
    control_ids: tuple[str, ...] = tuple(f"n{i}" for i in range(1, 17))
    modalities: tuple[str, ...] = ("EEG", "EMG", "RESP", "ALL_SLEEP")
    sleep_selection: str = "NREM"
    target_fs: float = 128.0
    line_freq: float = 50.0
    epoch_sec: float = 30.0
    min_keep_epochs: int = 5
    filter_method: str = "iir"
    n_jobs: int = 2
    random_seed: int = 1234
    delete_raw_after_process: bool = True
    request_timeout: int = 180
    graph: SmallWorldConfig = SmallWorldConfig(density=0.10, n_randomizations=5, rewires_per_edge=5, seed=1234)


def select_channels(ch_names: list[str], modality: str) -> list[int]:
    pat = re.compile(CHANNEL_REGEX[modality], flags=re.IGNORECASE)
    return [i for i, ch in enumerate(ch_names) if pat.search(str(ch))]


def channel_family(name: str) -> str:
    s = str(name).lower()
    if re.search(r"emg|chin|submental|submentalis|tibial", s):
        return "EMG"
    if re.search(r"resp|airflow|nasal|thor|abdo|abdominal|thoracic|sao2|spo2|flow", s):
        return "RESP"
    return "EEG"


def parse_cap_stage_intervals(txt_path: str | Path) -> list[tuple[float, float, str]]:
    intervals: list[tuple[float, float, str]] = []
    current = 0.0
    in_table = False
    with open(txt_path, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            s = line.strip()
            if not s:
                continue
            if s.startswith("Sleep Stage"):
                in_table = True
                continue
            if not in_table:
                continue
            parts = re.split(r"\t+", s)
            if len(parts) < 5:
                continue
            event, dur_s = parts[3].strip(), parts[4].strip()
            if event not in {"SLEEP-S0", "SLEEP-S1", "SLEEP-S2", "SLEEP-S3", "SLEEP-S4", "SLEEP-REM", "MT"}:
                continue
            try:
                dur = float(dur_s)
            except ValueError:
                continue
            intervals.append((current, current + dur, event))
            current += dur
    if not intervals:
        raise ValueError(f"No sleep-stage intervals found in {txt_path}")
    return intervals


def build_sleep_mask(n_times: int, sfreq: float, intervals, sleep_selection: str) -> np.ndarray:
    mask = np.zeros(int(n_times), dtype=bool)
    if sleep_selection == "WHOLE_NIGHT":
        mask[:] = True
        return mask
    if sleep_selection != "NREM":
        raise ValueError(f"Unknown sleep_selection: {sleep_selection}")
    for start, end, event in intervals:
        if event in NREM_EVENTS:
            i0 = max(0, int(round(start * sfreq)))
            i1 = min(n_times, int(round(end * sfreq)))
            if i1 > i0:
                mask[i0:i1] = True
    return mask


def preprocess_matrix(data_ch_by_t: np.ndarray, sfreq: float, names: list[str], modality: str, cfg: CAPSleepConfig) -> tuple[np.ndarray, list[str], float, dict]:
    sfreq = float(sfreq)
    x = np.asarray(data_ch_by_t, dtype=float)
    if sfreq > cfg.target_fs:
        x = mne.filter.resample(x, down=sfreq / cfg.target_fs, npad="auto", axis=1)
        sfreq = float(cfg.target_fs)
    out = np.zeros_like(x, dtype=float)
    iir_params = dict(order=4, ftype="butter") if cfg.filter_method == "iir" else None
    for j, ch_name in enumerate(names):
        fam = modality if modality != "ALL_SLEEP" else channel_family(ch_name)
        params = PREPROC[fam]
        y = x[j].astype(float)
        if params["notch"] and sfreq > 2 * cfg.line_freq:
            y = mne.filter.notch_filter(y, Fs=sfreq, freqs=[cfg.line_freq], method=cfg.filter_method, iir_params=iir_params, phase="zero", verbose=False)
        if params["l_freq"] is not None or params["h_freq"] is not None:
            y = mne.filter.filter_data(y, sfreq=sfreq, l_freq=params["l_freq"], h_freq=params["h_freq"], method=cfg.filter_method, iir_params=iir_params, phase="zero", verbose=False)
        out[j] = robust_zscore(y)
    epoch_len = max(1, int(round(cfg.epoch_sec * sfreq)))
    n_epochs = out.shape[1] // epoch_len
    if n_epochs == 0:
        raise ValueError("Signal too short after preprocessing.")
    out = out[:, : n_epochs * epoch_len]
    epochs = out.reshape(out.shape[0], n_epochs, epoch_len)
    ptp = np.ptp(epochs, axis=2)
    keep = np.ones(n_epochs, dtype=bool)
    for ch in range(ptp.shape[0]):
        vals = ptp[ch]
        med = np.median(vals)
        mad = np.median(np.abs(vals - med))
        scale = 1.4826 * mad if mad > 0 else (np.std(vals) if np.std(vals) > 0 else 1.0)
        keep &= vals <= (med + 6.0 * scale)
    if keep.sum() < cfg.min_keep_epochs:
        raise ValueError(f"Too few clean epochs kept ({keep.sum()}).")
    cleaned = epochs[:, keep, :].reshape(out.shape[0], -1)
    qc = {
        "sfreq_used": float(sfreq),
        "epoch_sec": float(cfg.epoch_sec),
        "n_epochs_total": int(n_epochs),
        "n_epochs_kept": int(keep.sum()),
        "pct_epochs_kept": float(100.0 * keep.mean()),
        "n_channels": int(out.shape[0]),
        "T_clean_samples": int(cleaned.shape[1]),
    }
    return cleaned.T, names, sfreq, qc


def download_subject(subject_id: str, cfg: CAPSleepConfig) -> dict[str, Path]:
    subject_dir = Path(cfg.tmp_dir) / subject_id
    subject_dir.mkdir(parents=True, exist_ok=True)
    files = {"edf": f"{subject_id}.edf", "txt": f"{subject_id}.txt", "st": f"{subject_id}.edf.st"}
    out = {}
    session = requests.Session()
    for key, fname in files.items():
        local = subject_dir / fname
        if local.exists() and local.stat().st_size > 0:
            out[key] = local
            continue
        url = urljoin(BASE_URL, fname)
        last = None
        for attempt in range(1, 6):
            try:
                with session.get(url, stream=True, timeout=cfg.request_timeout) as r:
                    r.raise_for_status()
                    tmp = str(local) + ".part"
                    with open(tmp, "wb") as f:
                        for chunk in r.iter_content(1024 * 1024):
                            if chunk:
                                f.write(chunk)
                    os.replace(tmp, local)
                out[key] = local
                break
            except Exception as exc:
                last = exc
                time.sleep(attempt)
        else:
            if key != "st":
                raise RuntimeError(f"Failed to download {url}: {last}")
    return out


def load_subject_modalities(edf_path: Path, txt_path: Path, cfg: CAPSleepConfig) -> dict[str, tuple[np.ndarray, list[str], float, dict]]:
    raw = mne.io.read_raw_edf(edf_path, preload=True, verbose="ERROR")
    intervals = parse_cap_stage_intervals(txt_path)
    sfreq = float(raw.info["sfreq"])
    mask = build_sleep_mask(raw.n_times, sfreq, intervals, cfg.sleep_selection)
    if mask.sum() == 0:
        raise ValueError(f"No samples kept for {cfg.sleep_selection}")
    outputs = {}
    for modality in cfg.modalities:
        idx = select_channels(raw.ch_names, modality)
        if not idx:
            continue
        data = raw.get_data(picks=idx)[:, mask]
        names = [raw.ch_names[i] for i in idx]
        outputs[modality] = preprocess_matrix(data, sfreq, names, modality, cfg)
    return outputs


def _subject_task(subject_id: str, cfg: CAPSleepConfig):
    try:
        local = download_subject(subject_id, cfg)
        modality_data = load_subject_modalities(local["edf"], local["txt"], cfg)
        sid_num = int(subject_id[1:])
        result = {}
        for mi, modality in enumerate(cfg.modalities):
            if modality not in modality_data:
                result[modality] = (None, {"dataset": cfg.dataset_name, "channel_mode": modality, "sleep_selection": cfg.sleep_selection, "method": "ALL", "record_or_patient": subject_id, "reason": "No valid channels found"})
                continue
            sig, names, fs, qc = modality_data[modality]
            rows = extract_metrics_from_matrix(sig, config=cfg.graph, seed_base=cfg.random_seed + 100000 * sid_num + 1000 * mi)
            for method in rows:
                rows[method].update({"patient_id": subject_id, "dataset": cfg.dataset_name, "channel_mode": modality, "source_file": local["edf"].name, "filter_method": cfg.filter_method, **qc})
            result[modality] = (rows, None)
        return subject_id, result
    except Exception as exc:
        return subject_id, {"__fatal__": str(exc)}
    finally:
        if cfg.delete_raw_after_process:
            shutil.rmtree(Path(cfg.tmp_dir) / subject_id, ignore_errors=True)


def run_all_modalities(cfg: CAPSleepConfig = CAPSleepConfig()) -> None:
    Path(cfg.tmp_dir).mkdir(parents=True, exist_ok=True)
    results = Parallel(n_jobs=cfg.n_jobs, backend="loky")(
        delayed(_subject_task)(sid, cfg) for sid in tqdm(cfg.control_ids, desc="CAP sleep subjects")
    )
    for subject_id, payload in results:
        if "__fatal__" in payload:
            for modality in cfg.modalities:
                out_dir = Path(cfg.out_base_dir) / cfg.dataset_name / modality
                out_dir.mkdir(parents=True, exist_ok=True)
                p = out_dir / f"skipped_{cfg.dataset_name}_{modality}_{cfg.sleep_selection}.csv"
                pd.DataFrame([{"dataset": cfg.dataset_name, "channel_mode": modality, "sleep_selection": cfg.sleep_selection, "method": "ALL", "record_or_patient": subject_id, "reason": payload["__fatal__"]}]).to_csv(p, mode="a", header=not p.exists(), index=False)
            continue
        for modality, pack in payload.items():
            if modality not in cfg.modalities:
                continue
            out_dir = Path(cfg.out_base_dir) / cfg.dataset_name / modality
            out_dir.mkdir(parents=True, exist_ok=True)
            rows, skip = pack
            if rows:
                for method in ["QTN", "GAF", "MTF"]:
                    p = out_dir / f"metrics_{method}_{cfg.dataset_name}_{modality}_{cfg.sleep_selection}.csv"
                    pd.DataFrame([rows[method]]).to_csv(p, mode="a", header=not p.exists(), index=False)
            if skip:
                p = out_dir / f"skipped_{cfg.dataset_name}_{modality}_{cfg.sleep_selection}.csv"
                pd.DataFrame([skip]).to_csv(p, mode="a", header=not p.exists(), index=False)
