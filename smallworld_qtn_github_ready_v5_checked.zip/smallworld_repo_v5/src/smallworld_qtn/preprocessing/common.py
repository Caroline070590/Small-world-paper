"""Shared preprocessing utilities for electrophysiological/physiological pipelines."""
from __future__ import annotations

from typing import Optional, Tuple
import numpy as np
from scipy import signal


def robust_zscore(x: np.ndarray, max_abs_z: float = 10.0) -> np.ndarray:
    x = np.asarray(x, dtype=float)
    med = np.nanmedian(x)
    mad = np.nanmedian(np.abs(x - med))
    scale = 1.4826 * mad
    if not np.isfinite(scale) or scale == 0:
        std = np.nanstd(x)
        scale = std if np.isfinite(std) and std > 0 else 1.0
    return np.clip((x - med) / scale, -max_abs_z, max_abs_z)


def interpolate_short_gaps(x: np.ndarray, max_gap_frac: float = 0.05) -> np.ndarray:
    x = np.asarray(x, dtype=float).copy()
    n = x.size
    finite = np.isfinite(x)
    if n == 0 or finite.sum() == 0:
        return x
    if finite.all():
        return x
    idx = np.arange(n)
    x[~finite] = np.interp(idx[~finite], idx[finite], x[finite])
    starts = np.where(np.diff(np.r_[False, ~finite, False].astype(int)) == 1)[0]
    ends = np.where(np.diff(np.r_[False, ~finite, False].astype(int)) == -1)[0]
    max_gap = max((e - s) for s, e in zip(starts, ends)) if len(starts) else 0
    if max_gap > max_gap_frac * n:
        raise ValueError(f"Gap too long for safe interpolation: {max_gap} samples.")
    return x


def butter_sos_filter(
    x: np.ndarray,
    fs: Optional[float],
    low: Optional[float] = None,
    high: Optional[float] = None,
    order: int = 4,
) -> np.ndarray:
    """Zero-phase Butterworth filtering; returns unchanged signal when fs/cutoffs are invalid."""
    if fs is None or not np.isfinite(fs) or fs <= 0:
        return np.asarray(x, dtype=float)
    nyq = 0.5 * float(fs)
    if low is not None and high is not None:
        high = min(float(high), nyq * 0.99)
        low = float(low)
        if not (0 < low < high < nyq):
            return np.asarray(x, dtype=float)
        sos = signal.butter(order, [low / nyq, high / nyq], btype="bandpass", output="sos")
    elif low is not None:
        low = float(low)
        if not (0 < low < nyq):
            return np.asarray(x, dtype=float)
        sos = signal.butter(order, low / nyq, btype="highpass", output="sos")
    elif high is not None:
        high = min(float(high), nyq * 0.99)
        if not (0 < high < nyq):
            return np.asarray(x, dtype=float)
        sos = signal.butter(order, high / nyq, btype="lowpass", output="sos")
    else:
        return np.asarray(x, dtype=float)
    return signal.sosfiltfilt(sos, np.asarray(x, dtype=float))


def notch_filter(x: np.ndarray, fs: Optional[float], freq: float = 50.0, q: float = 30.0) -> np.ndarray:
    if fs is None or not np.isfinite(fs) or fs <= 0 or freq <= 0 or freq >= 0.5 * fs:
        return np.asarray(x, dtype=float)
    b, a = signal.iirnotch(w0=freq, Q=q, fs=float(fs))
    return signal.filtfilt(b, a, np.asarray(x, dtype=float))


def flat_fraction_scale_aware(x: np.ndarray) -> float:
    x = np.asarray(x, dtype=float)
    if x.size < 2:
        return 1.0
    dx = np.diff(x)
    scale = float(np.nanstd(x))
    eps = max(1e-12, 1e-6 * scale)
    return float(np.mean(np.abs(dx) <= eps))


def epoch_ptp_keep_mask(x: np.ndarray, fs: Optional[float], epoch_sec: float, threshold_mult: float = 6.0) -> np.ndarray:
    if fs is None or not np.isfinite(fs) or fs <= 0:
        return np.ones(1, dtype=bool)
    epoch_len = max(1, int(round(float(epoch_sec) * float(fs))))
    n_epochs = len(x) // epoch_len
    if n_epochs == 0:
        return np.zeros(0, dtype=bool)
    epochs = np.asarray(x[: n_epochs * epoch_len]).reshape(n_epochs, epoch_len)
    ptp = np.ptp(epochs, axis=1)
    med = float(np.median(ptp))
    mad = float(np.median(np.abs(ptp - med)))
    scale = 1.4826 * mad if mad > 0 else (float(np.std(ptp)) if np.std(ptp) > 0 else 1.0)
    return ptp <= (med + threshold_mult * scale)


def apply_epoch_mask(x: np.ndarray, mask: np.ndarray, fs: Optional[float], epoch_sec: float) -> Tuple[np.ndarray, dict]:
    if mask.size <= 1 or fs is None or not np.isfinite(fs) or fs <= 0:
        return np.asarray(x, dtype=float), {"n_epochs_total": np.nan, "n_epochs_kept": np.nan, "epochs_kept_frac": np.nan}
    epoch_len = max(1, int(round(float(epoch_sec) * float(fs))))
    n_epochs = len(x) // epoch_len
    y = np.asarray(x[: n_epochs * epoch_len]).reshape(n_epochs, epoch_len)[mask].reshape(-1)
    return y, {"n_epochs_total": int(n_epochs), "n_epochs_kept": int(mask.sum()), "epochs_kept_frac": float(mask.mean())}
