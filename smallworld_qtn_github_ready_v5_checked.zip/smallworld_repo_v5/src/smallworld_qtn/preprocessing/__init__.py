"""Dataset-specific preprocessing pipelines for the small-world QTN paper."""
