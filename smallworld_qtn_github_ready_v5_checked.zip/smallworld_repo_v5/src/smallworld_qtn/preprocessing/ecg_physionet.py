"""ECG preprocessing and metric extraction for PhysioNet ECG datasets.

Datasets supported by default:
- MIT-BIH Normal Sinus Rhythm Database (``nsrdb``)
- Fantasia Database (``fantasia``)

No plotting code is included.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Optional
import re
import warnings

import numpy as np
import pandas as pd
from scipy import signal
from joblib import Parallel, delayed
from tqdm import tqdm
import wfdb

from smallworld_qtn.network_metrics import SmallWorldConfig
from smallworld_qtn.pipeline import extract_metrics_from_matrix
from .common import robust_zscore, butter_sos_filter, interpolate_short_gaps

warnings.filterwarnings("ignore", category=RuntimeWarning)


@dataclass
class ECGConfig:
    target_fs: float = 250.0
    low_hz: float = 0.5
    high_hz: float = 40.0
    butter_order: int = 4
    max_samples: Optional[int] = None
    start_sample: int = 0
    n_jobs: int = 2
    batch_size: int = 4
    random_seed: int = 1234
    graph: SmallWorldConfig = SmallWorldConfig(density=0.10, n_randomizations=5, rewires_per_edge=5, seed=1234)


def _slice(x: np.ndarray, cfg: ECGConfig) -> np.ndarray:
    start = int(cfg.start_sample or 0)
    return x[start:, :] if cfg.max_samples is None else x[start:start + int(cfg.max_samples), :]


def preprocess_ecg_matrix(sig_t_by_lead: np.ndarray, fs: float, cfg: ECGConfig = ECGConfig()) -> tuple[np.ndarray, float]:
    """Detrend, band-pass filter, resample, and robust-zscore ECG leads."""
    x = np.asarray(sig_t_by_lead, dtype=float)
    if x.ndim != 2:
        raise ValueError("ECG signal must have shape (T, n_leads).")
    fs_used = float(fs)
    if fs_used <= 0 or not np.isfinite(fs_used):
        raise ValueError("Invalid sampling frequency.")
    if fs_used > cfg.target_fs:
        n_target = int(round(x.shape[0] * cfg.target_fs / fs_used))
        x = signal.resample(x, n_target, axis=0)
        fs_used = float(cfg.target_fs)
    out = np.zeros_like(x, dtype=float)
    for j in range(x.shape[1]):
        ch = interpolate_short_gaps(x[:, j], max_gap_frac=0.05)
        ch = signal.detrend(ch, type="constant")
        ch = butter_sos_filter(ch, fs=fs_used, low=cfg.low_hz, high=cfg.high_hz, order=cfg.butter_order)
        out[:, j] = robust_zscore(ch)
    return out, fs_used


def detect_fantasia_age_group(record_name: str, record_obj=None) -> str:
    texts = [str(record_name).lower()]
    comments = getattr(record_obj, "comments", None)
    if comments is not None:
        texts.extend(str(c).lower() for c in comments)
    joined = " | ".join(texts)
    if re.search(r"\bold\b|\belderly\b", joined):
        return "old"
    if re.search(r"\byoung\b", joined):
        return "young"
    return "unknown"


def process_record(pn_dir: str, record_name: str, dataset_name: str, cfg: ECGConfig, task_i: int) -> dict[str, dict]:
    rec = wfdb.rdrecord(record_name, pn_dir=pn_dir)
    sig = _slice(rec.p_signal, cfg)
    clean, fs_used = preprocess_ecg_matrix(sig, float(rec.fs), cfg)
    rows = extract_metrics_from_matrix(clean, config=cfg.graph, seed_base=cfg.random_seed + 100000 * task_i)
    age_group = detect_fantasia_age_group(record_name, rec) if dataset_name == "fantasia" else "na"
    for method in rows:
        rows[method].update({
            "patient_id": record_name,
            "dataset": dataset_name,
            "age_group": age_group,
            "fs_hz_original": float(rec.fs),
            "fs_hz_used": float(fs_used),
            "n_leads": int(clean.shape[1]),
        })
    return rows


def _task(dataset_name: str, pn_dir: str, rec: str, cfg: ECGConfig, task_i: int):
    try:
        return rec, process_record(pn_dir, rec, dataset_name, cfg, task_i), None
    except Exception as exc:
        return rec, None, {"dataset": dataset_name, "method": "ALL", "record_or_patient": rec, "reason": str(exc)}


def run_dataset(dataset_name: str, pn_dir: str, out_dir: str, cfg: ECGConfig = ECGConfig()) -> None:
    """Run ECG preprocessing + QTN/GAF/MTF metric extraction and write CSVs."""
    Path(out_dir).mkdir(parents=True, exist_ok=True)
    paths = {m: Path(out_dir) / f"metrics_{m}_{dataset_name}.csv" for m in ["QTN", "GAF", "MTF"]}
    skip_path = Path(out_dir) / f"skipped_{dataset_name}.csv"
    records = sorted(wfdb.get_record_list(pn_dir))
    tasks = [(rec, i + 1) for i, rec in enumerate(records)]
    buffers = {m: [] for m in ["QTN", "GAF", "MTF"]}
    skips = []
    for start in tqdm(range(0, len(tasks), cfg.batch_size), desc=f"{dataset_name} ECG batches"):
        chunk = tasks[start:start + cfg.batch_size]
        results = Parallel(n_jobs=cfg.n_jobs, backend="loky")(
            delayed(_task)(dataset_name, pn_dir, rec, cfg, ti) for rec, ti in chunk
        )
        for _, rows, skip in results:
            if rows:
                for method in buffers:
                    buffers[method].append(rows[method])
            if skip:
                skips.append(skip)
        for method, rows in buffers.items():
            if rows:
                pd.DataFrame(rows).to_csv(paths[method], mode="a", header=not paths[method].exists(), index=False)
                buffers[method].clear()
        if skips:
            pd.DataFrame(skips).to_csv(skip_path, mode="a", header=not skip_path.exists(), index=False)
            skips.clear()
