"""Respiratory aeration preprocessing for the PhysioNet respiratory/heart-rate dataset.

The module processes the CSV files in ``Processed_Dataset`` and extracts QTN/GAF/MTF
small-world features. No plotting code is included.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Optional
from urllib.parse import urljoin
import re
import warnings

import requests
import numpy as np
import pandas as pd
from scipy import signal
from joblib import Parallel, delayed
from tqdm import tqdm

from smallworld_qtn.network_metrics import SmallWorldConfig
from smallworld_qtn.pipeline import extract_metrics_from_matrix
from .common import robust_zscore, interpolate_short_gaps, butter_sos_filter, flat_fraction_scale_aware, epoch_ptp_keep_mask, apply_epoch_mask

warnings.filterwarnings("ignore", category=RuntimeWarning)


BASE_URL = "https://physionet.org/files/respiratory-heartrate-dataset/1.0.0/"
PROCESSED_BASE_URL = urljoin(BASE_URL, "Processed_Dataset/")
SHA256_URL = urljoin(BASE_URL, "SHA256SUMS.txt")
SIGNAL_COLS = ["PSD Flow [L/s]", "EIT Global Aeration"]


@dataclass
class RespAerationConfig:
    dataset_name: str = "resp_aeration_stream"
    out_dir: str = "resp_outputs/out_resp_aeration_stream"
    tmp_dir: str = "tmp_resp_aeration"
    default_fs: Optional[float] = None
    low_hz: float = 0.01
    high_hz: float = 1.0
    min_valid_samples: int = 200
    min_unique_values: int = 20
    max_flat_frac: float = 0.20
    epoch_sec: float = 30.0
    min_keep_epochs: int = 3
    n_jobs: int = 2
    batch_size: int = 4
    random_seed: int = 1234
    delete_raw_after_process: bool = True
    graph: SmallWorldConfig = SmallWorldConfig(density=0.10, n_randomizations=10, rewires_per_edge=5, seed=1234)


def discover_processed_files() -> list[str]:
    r = requests.get(SHA256_URL, timeout=120)
    r.raise_for_status()
    pat = re.compile(r"Processed_Dataset/(ProcessedData_Subject\d+_[A-Za-z0-9_]+\.csv)$")
    return sorted(set(m.group(1) for line in r.text.splitlines() if (m := pat.search(line))))


def subject_id_from_filename(fname: str) -> str:
    m = re.search(r"Subject(\d+)", fname, flags=re.IGNORECASE)
    return f"S{int(m.group(1)):02d}" if m else Path(fname).stem


def trial_from_filename(fname: str) -> str:
    m = re.search(r"ProcessedData_Subject\d+_(.+)\.csv$", fname, flags=re.IGNORECASE)
    return m.group(1) if m else "UNKNOWN"


def preprocess_resp_signal(x: np.ndarray, cfg: RespAerationConfig) -> tuple[np.ndarray, dict]:
    qc = {"n_total": int(len(x))}
    x = np.asarray(x, dtype=float)
    finite = np.isfinite(x)
    qc["missing_frac_before"] = float(1.0 - finite.mean()) if x.size else np.nan
    if finite.sum() < cfg.min_valid_samples:
        raise ValueError("Too few valid samples before preprocessing.")
    x = interpolate_short_gaps(x, max_gap_frac=0.01)
    x = signal.detrend(x, type="linear")
    x = butter_sos_filter(x, fs=cfg.default_fs, low=cfg.low_hz, high=cfg.high_hz)
    qc["std_before_z"] = float(np.std(x))
    qc["n_unique_before_z"] = int(np.unique(np.round(x, 10)).size)
    qc["flat_frac_before_z"] = float(flat_fraction_scale_aware(x))
    if qc["std_before_z"] <= 1e-8:
        raise ValueError("Signal variance too small.")
    if qc["n_unique_before_z"] < cfg.min_unique_values:
        raise ValueError("Too few unique values.")
    if qc["flat_frac_before_z"] > cfg.max_flat_frac:
        raise ValueError("Too much flat signal.")
    mask = epoch_ptp_keep_mask(x, cfg.default_fs, cfg.epoch_sec, threshold_mult=6.0)
    x, epoch_qc = apply_epoch_mask(x, mask, cfg.default_fs, cfg.epoch_sec)
    qc.update(epoch_qc)
    if np.isfinite(qc.get("n_epochs_kept", np.nan)) and qc["n_epochs_kept"] < cfg.min_keep_epochs:
        raise ValueError("Too few clean epochs kept.")
    x = robust_zscore(x)
    if x.size < cfg.min_valid_samples:
        raise ValueError("Too few samples after preprocessing.")
    qc["n_final"] = int(x.size)
    return x, qc


def load_resp_csv_matrix(path: str | Path, cfg: RespAerationConfig) -> tuple[np.ndarray, list[str], pd.DataFrame]:
    df = pd.read_csv(path)
    cols = [c for c in SIGNAL_COLS if c in df.columns]
    if not cols:
        raise ValueError(f"None of requested columns found. Available columns: {list(df.columns)}")
    cleaned, qc_rows = [], []
    for col in cols:
        y, qc = preprocess_resp_signal(pd.to_numeric(df[col], errors="coerce").to_numpy(float), cfg)
        cleaned.append(y)
        qc["signal_name"] = col
        qc_rows.append(qc)
    n = min(len(y) for y in cleaned)
    return np.column_stack([y[:n] for y in cleaned]), cols, pd.DataFrame(qc_rows)


def _download(fname: str, cfg: RespAerationConfig) -> Path:
    Path(cfg.tmp_dir).mkdir(parents=True, exist_ok=True)
    local = Path(cfg.tmp_dir) / fname
    if not local.exists():
        with requests.get(urljoin(PROCESSED_BASE_URL, fname), stream=True, timeout=120) as r:
            r.raise_for_status()
            with open(local, "wb") as f:
                for chunk in r.iter_content(1024 * 1024):
                    if chunk:
                        f.write(chunk)
    return local


def _task(fname: str, cfg: RespAerationConfig, task_i: int):
    try:
        local = _download(fname, cfg)
        sig, cols, qc_df = load_resp_csv_matrix(local, cfg)
        rows = extract_metrics_from_matrix(sig, config=cfg.graph, seed_base=cfg.random_seed + 100000 * task_i)
        qc = qc_df.mean(numeric_only=True).to_dict()
        for method in rows:
            rows[method].update({
                "file_id": Path(fname).stem,
                "patient_id": subject_id_from_filename(fname),
                "trial": trial_from_filename(fname),
                "dataset": cfg.dataset_name,
                "source_file": fname,
                "signal_cols": ";".join(cols),
                "fs_hz_used": cfg.default_fs if cfg.default_fs is not None else np.nan,
                **{f"qc_{k}_mean": v for k, v in qc.items()},
            })
        return fname, rows, None
    except Exception as exc:
        return fname, None, {"dataset": cfg.dataset_name, "method": "ALL", "record_or_patient": fname, "reason": str(exc)}
    finally:
        try:
            if cfg.delete_raw_after_process:
                (Path(cfg.tmp_dir) / fname).unlink(missing_ok=True)
        except Exception:
            pass


def run_dataset(cfg: RespAerationConfig = RespAerationConfig()) -> None:
    Path(cfg.out_dir).mkdir(parents=True, exist_ok=True)
    files = discover_processed_files()
    pd.DataFrame([{"file_name": f, "patient_id": subject_id_from_filename(f), "trial": trial_from_filename(f)} for f in files]).to_csv(Path(cfg.out_dir) / f"manifest_{cfg.dataset_name}.csv", index=False)
    buffers = {m: [] for m in ["QTN", "GAF", "MTF"]}
    skips = []
    tasks = [(f, i + 1) for i, f in enumerate(files)]
    for start in tqdm(range(0, len(tasks), cfg.batch_size), desc="respiratory aeration batches"):
        results = Parallel(n_jobs=cfg.n_jobs, backend="loky")(
            delayed(_task)(fname, cfg, ti) for fname, ti in tasks[start:start + cfg.batch_size]
        )
        for _, rows, skip in results:
            if rows:
                for method in buffers:
                    buffers[method].append(rows[method])
            if skip:
                skips.append(skip)
        for method, rows in buffers.items():
            if rows:
                p = Path(cfg.out_dir) / f"metrics_{method}_{cfg.dataset_name}_per_file.csv"
                pd.DataFrame(rows).to_csv(p, mode="a", header=not p.exists(), index=False)
                buffers[method].clear()
        if skips:
            p = Path(cfg.out_dir) / f"skipped_{cfg.dataset_name}.csv"
            pd.DataFrame(skips).to_csv(p, mode="a", header=not p.exists(), index=False)
            skips.clear()
