"""FieldTrip Subject01 CTF-MEG preprocessing and QTN/GAF/MTF metric extraction.

No plotting code is included.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Optional
import os
import shutil
import zipfile
import warnings

import requests
import numpy as np
import pandas as pd
from scipy import signal
import mne

from smallworld_qtn.network_metrics import SmallWorldConfig
from smallworld_qtn.pipeline import extract_metrics_from_matrix
from .common import robust_zscore, interpolate_short_gaps, butter_sos_filter, notch_filter

warnings.filterwarnings("ignore", category=RuntimeWarning)

FIELDTRIP_ZIP_URL = "https://download.fieldtriptoolbox.org/tutorial/Subject01.zip"


@dataclass
class FieldTripMEGConfig:
    dataset_name: str = "fieldtrip_subject01_meg"
    subject_id: str = "Subject01"
    out_dir: str = "fieldtrip_subject01_preprocessed/meg"
    raw_root: str = "fieldtrip_subject01_preprocessed/raw_cache"
    max_seconds: Optional[float] = 60.0
    target_fs: float = 250.0
    low_hz: float = 0.5
    high_hz: float = 40.0
    notch_freqs: tuple[float, ...] = (50.0, 100.0)
    min_valid_samples: int = 200
    min_valid_channels: int = 10
    random_seed: int = 1234
    force_redownload: bool = False
    force_reextract: bool = False
    graph: SmallWorldConfig = SmallWorldConfig(density=0.10, n_randomizations=10, rewires_per_edge=5, seed=1234)


def download_file(url: str, local_path: Path, force: bool = False) -> None:
    local_path.parent.mkdir(parents=True, exist_ok=True)
    if local_path.exists() and local_path.stat().st_size > 0 and not force:
        return
    with requests.get(url, stream=True, timeout=120) as r:
        r.raise_for_status()
        tmp = str(local_path) + ".part"
        with open(tmp, "wb") as f:
            for chunk in r.iter_content(1024 * 1024):
                if chunk:
                    f.write(chunk)
        os.replace(tmp, local_path)


def extract_zip(zip_path: Path, extract_dir: Path, force: bool = False) -> None:
    if extract_dir.exists() and not force:
        return
    if force and extract_dir.exists():
        shutil.rmtree(extract_dir)
    extract_dir.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(zip_path, "r") as zf:
        zf.extractall(extract_dir)


def find_ds_directory(root_dir: Path) -> Path:
    candidates = [p for p in root_dir.rglob("*.ds") if p.is_dir()]
    if not candidates:
        raise FileNotFoundError(f"No .ds directory found under {root_dir}")
    exact = [p for p in candidates if p.name == "Subject01.ds"]
    return exact[0] if exact else sorted(candidates)[0]


def preprocess_meg_channel(x: np.ndarray, fs: float, cfg: FieldTripMEGConfig) -> np.ndarray:
    if x.size < cfg.min_valid_samples:
        raise ValueError("Too few samples.")
    x = interpolate_short_gaps(x, max_gap_frac=0.05)
    x = signal.detrend(x, type="constant")
    x = butter_sos_filter(x, fs=fs, low=cfg.low_hz, high=cfg.high_hz, order=4)
    for f0 in cfg.notch_freqs:
        x = notch_filter(x, fs=fs, freq=f0, q=30.0)
    if np.std(x) <= 1e-20 and np.ptp(x) <= 1e-18:
        raise ValueError("Variance too small.")
    return robust_zscore(x)


def load_meg_from_ctf_ds(ds_path: Path, cfg: FieldTripMEGConfig) -> tuple[np.ndarray, float, dict]:
    raw = mne.io.read_raw_ctf(str(ds_path), preload=False, system_clock="ignore", verbose="ERROR")
    picks = mne.pick_types(raw.info, meg=True, ref_meg=False, eeg=False, stim=False, eog=False, ecg=False, misc=False, exclude="bads")
    if len(picks) == 0:
        raise ValueError("No CTF MEG data channels found.")
    fs_native = float(raw.info["sfreq"])
    stop = raw.n_times if cfg.max_seconds is None else min(raw.n_times, int(round(cfg.max_seconds * fs_native)))
    data = raw.get_data(picks=picks, start=0, stop=stop)
    x = np.asarray(data, dtype=float).T
    fs_used = fs_native
    if cfg.target_fs and fs_used > cfg.target_fs:
        n_out = int(round(x.shape[0] * cfg.target_fs / fs_used))
        x = signal.resample(x, n_out, axis=0)
        fs_used = float(cfg.target_fs)
    kept = []
    dropped = 0
    for j in range(x.shape[1]):
        try:
            kept.append(preprocess_meg_channel(x[:, j], fs_used, cfg))
        except Exception:
            dropped += 1
    if len(kept) < cfg.min_valid_channels:
        raise ValueError(f"Too few valid channels after QC: kept={len(kept)}, dropped={dropped}")
    min_len = min(len(y) for y in kept)
    clean = np.column_stack([y[:min_len] for y in kept])
    qc = {"n_channels_before_qc": int(x.shape[1]), "n_channels_after_qc": int(clean.shape[1]), "n_channels_dropped_qc": int(dropped)}
    return clean, fs_used, qc


def run_fieldtrip_meg(cfg: FieldTripMEGConfig = FieldTripMEGConfig()) -> dict[str, str]:
    out_dir = Path(cfg.out_dir)
    raw_root = Path(cfg.raw_root)
    out_dir.mkdir(parents=True, exist_ok=True)
    raw_root.mkdir(parents=True, exist_ok=True)
    zip_path = raw_root / "Subject01.zip"
    extract_dir = raw_root / "Subject01_extracted"
    download_file(FIELDTRIP_ZIP_URL, zip_path, force=cfg.force_redownload)
    extract_zip(zip_path, extract_dir, force=cfg.force_reextract)
    ds_path = find_ds_directory(extract_dir)
    clean, fs, qc = load_meg_from_ctf_ds(ds_path, cfg)
    rows = extract_metrics_from_matrix(clean, config=cfg.graph, seed_base=cfg.random_seed)
    paths = {}
    for method in ["QTN", "GAF", "MTF"]:
        rows[method].update({
            "file_id": ds_path.stem,
            "subject_id": cfg.subject_id,
            "dataset": cfg.dataset_name,
            "source_file": str(ds_path),
            "fs_hz": float(fs),
            "meg_max_seconds": cfg.max_seconds if cfg.max_seconds is not None else np.nan,
            "meg_target_fs": cfg.target_fs,
            "meg_bandpass_low": cfg.low_hz,
            "meg_bandpass_high": cfg.high_hz,
            "meg_notch": ";".join(str(f) for f in cfg.notch_freqs),
            **qc,
        })
        p = out_dir / f"metrics_{method}_{cfg.dataset_name}_per_file.csv"
        pd.DataFrame([rows[method]]).to_csv(p, index=False)
        paths[method] = str(p)
    pd.DataFrame([{"source_file": str(ds_path), "file_id": ds_path.stem, "subject_id": cfg.subject_id, "dataset": cfg.dataset_name}]).to_csv(out_dir / f"manifest_{cfg.dataset_name}.csv", index=False)
    return paths
