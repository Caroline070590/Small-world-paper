"""Shared feature-extraction pipeline: cleaned signals -> QTN/GAF/MTF network metrics."""
from __future__ import annotations

from typing import Iterable
import numpy as np
import pandas as pd

from .representations import compute_q_from_t, q_length_representations
from .network_metrics import SmallWorldConfig, compute_smallworld_metrics_from_w


def extract_metrics_from_matrix(
    signals_t_by_ch: np.ndarray,
    lags: Iterable[int] = (1, 2, 3),
    config: SmallWorldConfig | None = None,
    seed_base: int = 1234,
) -> dict[str, dict]:
    """Average QTN/GAF/MTF metrics across columns/channels/regions."""
    signals = np.asarray(signals_t_by_ch, dtype=float)
    if signals.ndim == 1:
        signals = signals[:, None]
    if signals.ndim != 2:
        raise ValueError("signals_t_by_ch must be 1D or 2D with shape (T, n_channels).")
    t = signals.shape[0]
    if t < 50:
        raise ValueError("Too few samples after preprocessing.")
    q = compute_q_from_t(t)
    config = config or SmallWorldConfig()
    per_method: dict[str, list[dict]] = {"QTN": [], "GAF": [], "MTF": []}
    for j in range(signals.shape[1]):
        x = signals[:, j]
        x = x[np.isfinite(x)]
        if x.size < 50:
            continue
        reps = q_length_representations(x, q=q, lags=lags)
        for method in ["QTN", "GAF", "MTF"]:
            method_config = SmallWorldConfig(
                density=config.density,
                n_randomizations=config.n_randomizations,
                rewires_per_edge=config.rewires_per_edge,
                seed=int(seed_base + 100 * j + {"QTN": 1, "GAF": 2, "MTF": 3}[method]),
            )
            per_method[method].append(
                compute_smallworld_metrics_from_w(
                    reps[method],
                    config=method_config,
                    use_abs_for_threshold=(method == "GAF"),
                )
            )
    out: dict[str, dict] = {}
    for method, rows in per_method.items():
        if not rows:
            raise ValueError(f"No valid channels/signals produced metrics for {method}.")
        out[method] = pd.DataFrame(rows).mean(numeric_only=True).to_dict()
        out[method].update({"n_signals": int(signals.shape[1]), "T_used_samples": int(t), "Q_used": int(q)})
    return out
