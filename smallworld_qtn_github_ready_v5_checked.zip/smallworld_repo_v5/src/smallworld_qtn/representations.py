"""Time-series-to-matrix representations used in the paper.

This module contains only representation code. It does not download data,
preprocess signals, compute graph metrics, or make plots.

Implemented representations
---------------------------
- QG/QTN: Quantile graph / quantile transition network
- GAF: Gramian Angular Field
- MTF: Markov Transition Field
"""
from __future__ import annotations

from typing import Iterable, Tuple
import numpy as np


def clean_1d(x: np.ndarray, min_len: int = 2) -> np.ndarray:
    """Return a finite 1D float array."""
    arr = np.asarray(x, dtype=float).ravel()
    arr = arr[np.isfinite(arr)]
    if arr.size < min_len:
        raise ValueError(f"Signal must contain at least {min_len} finite samples.")
    return arr


def compute_q_from_t(t: int, minimum: int = 3) -> int:
    """Quantile-bin rule used in the manuscript: Q = round(2*T^(1/3))."""
    if int(t) <= 1:
        raise ValueError("Time-series length T must be > 1.")
    return max(int(minimum), int(round(2 * (int(t) ** (1.0 / 3.0)))))


def downsample_to_length(x: np.ndarray, length: int) -> np.ndarray:
    """Linearly resample a 1D signal to a fixed length."""
    x = clean_1d(x, min_len=1)
    length = int(length)
    if length <= 1:
        return x[:1].copy()
    if x.size == length:
        return x.copy()
    if x.size < 2:
        return np.full(length, float(x[0]), dtype=float)
    xp = np.linspace(0.0, 1.0, x.size)
    return np.interp(np.linspace(0.0, 1.0, length), xp, x).astype(float)


def quantile_states(x: np.ndarray, q: int | None = None) -> np.ndarray:
    """Discretize a signal into quantile-defined integer states [0, q-1]."""
    x = clean_1d(x)
    q = compute_q_from_t(x.size) if q is None else int(q)
    if q < 2:
        raise ValueError("q must be >= 2.")
    # Rank-based quantiles are robust to scale and outliers.
    ranks = np.argsort(np.argsort(x, kind="mergesort"), kind="mergesort")
    states = np.floor(q * ranks / x.size).astype(int)
    return np.clip(states, 0, q - 1)


def quantile_graph(
    x: np.ndarray,
    q: int | None = None,
    lags: Iterable[int] = (1, 2, 3),
    normalize: bool = False,
) -> np.ndarray:
    """Build a QG/QTN transition-count matrix from selected temporal lags."""
    states = quantile_states(x, q=q)
    q_eff = int(states.max() + 1)
    mat = np.zeros((q_eff, q_eff), dtype=float)
    n = states.size
    for lag in lags:
        lag = int(lag)
        if lag <= 0 or lag >= n:
            continue
        np.add.at(mat, (states[:-lag], states[lag:]), 1.0)
    if normalize and mat.sum() > 0:
        mat /= mat.sum()
    return mat


def symmetrize_quantile_graph(qg: np.ndarray) -> np.ndarray:
    """Convert a directed QG matrix to an undirected weighted matrix."""
    qg = np.asarray(qg, dtype=float)
    return qg + qg.T


def gramian_angular_field(x: np.ndarray) -> np.ndarray:
    """Compute the Gramian Angular Summation Field from a 1D signal."""
    x = clean_1d(x)
    mn, mx = float(np.min(x)), float(np.max(x))
    if np.isclose(mx, mn):
        scaled = np.zeros_like(x, dtype=float)
    else:
        scaled = 2.0 * (x - mn) / (mx - mn) - 1.0
    scaled = np.clip(scaled, -1.0, 1.0)
    phi = np.arccos(scaled)
    return np.cos(phi[:, None] + phi[None, :])


def markov_transition_field(x: np.ndarray, q: int | None = None) -> Tuple[np.ndarray, np.ndarray]:
    """Compute the MTF matrix and its underlying QxQ Markov transition matrix."""
    states = quantile_states(x, q=q)
    q_eff = int(states.max() + 1)
    counts = np.zeros((q_eff, q_eff), dtype=float)
    if states.size > 1:
        np.add.at(counts, (states[:-1], states[1:]), 1.0)
    row_sums = counts.sum(axis=1, keepdims=True)
    trans = np.divide(counts, row_sums, out=np.zeros_like(counts), where=row_sums != 0)
    mtf = trans[states[:, None], states[None, :]]
    return mtf, trans


def q_length_representations(x: np.ndarray, q: int | None = None, lags: Iterable[int] = (1, 2, 3)) -> dict:
    """Return QG, GAF, and MTF matrices using a common Q for one signal."""
    x = clean_1d(x)
    q = compute_q_from_t(x.size) if q is None else int(q)
    qg = symmetrize_quantile_graph(quantile_graph(x, q=q, lags=lags, normalize=False))
    x_q = downsample_to_length(x, q)
    gaf = gramian_angular_field(x_q)
    mtf, markov = markov_transition_field(x_q, q=q)
    return {"QTN": qg, "GAF": gaf, "MTF": mtf, "MTF_MARKOV": markov, "Q": q}
